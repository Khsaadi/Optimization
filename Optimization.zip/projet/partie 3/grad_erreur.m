function z=grad_erreur(a,b,t,y)
s=0;
k=0;
for i=1:102
    s=s+(exp(b*t(i))-1)*(y(i)-a+a*exp(b*t(i))); %cette fonction calcule le gradient de l'erreur E 
end
for j=1:102
    k=k+a*t(j)*exp(b*t(j))*(y(j)-a+a*exp(b*t(j)));
end
z=[(2*s/erreur(a,b,t,y));(2*k/(erreur(a,b,t,y)))]; %appel � la fonction erreur 
end