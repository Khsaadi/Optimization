function i=inertie(a0,v0,pas,eps,nu,t,y)
v1=nu.*v0+pas.*grad_erreur(a0(1),a0(2),t,y); %fonction permettant de minimiser l'erreur 
a1=a0-v1;
I=[a0,a1];
i=1;
while(norm(a1-a0)>eps)
    a0=a1 ;
    v0=v1;
    l=grad_erreur(a0(1),a0(2),t,y);
    j=pas*l;
    v1=nu.*v0+j;
    a1=a0-v1;
i=i+1;
    I=[I,a1];
end
I;
end

