function i=gradientpasfixe(x0,rou,eps,t,y)
x1=x0-rou*grad_erreur(x0(1),x0(2),t,y);  %d�terminer les param�tres minimisant l'erreur
A=[x0 x1];
i=1;
while(norm(x1-x0)>eps)
    x0=x1;
    x1=x1-rou*grad_erreur(x1(1),x1(2),t,y); %faisant appel � la fonction grad-erreur
    A=[A x1];
    i=i+1;
end


