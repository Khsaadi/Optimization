function a1=nesterov(a0,v0,pas,eps,nu,t,y)
v1=nu.*v0+pas.*grad_erreur(a0(1)-nu.*v0(1),a0(2)-nu.*v0(2),t,y); %minimiser l"erreur 
a1=a0-v1 ;
X=[a0,a1];
i=1;
while(norm(a1-a0)>eps)
    a0=a1 ;
    v0=v1;
    aa= a0-nu.*v0 ;
    l=grad_erreur(aa(1),aa(2),t,y) ;
    j=pas*l;
    v1=nu.*v0 + j;
    a1=a0-v1 ;
    X=[X,a1];
i=i+1;
end
a1;
end