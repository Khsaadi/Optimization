function s=erreur(a,b,t,y) %calcule l'erreur pour des param�tres donn�s
s=0;
for i=1:102
    f=y(i)-a+a.*exp(b.*t(i));
    s=s+f^2;
end
s=log(s);
end



