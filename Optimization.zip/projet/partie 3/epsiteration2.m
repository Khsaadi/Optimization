function epsiteration2 (t,y)
v=linspace(0.00001,0.1,10);   %le vecteur des epsilon 
l=-log(v);                    % le vecteur de -log(epsilon)
z=ones(10);
m=ones(10);

for i =1 : length(l)
z(i)=gradientpasfixe([1;1],0.001,l(i),t,y);%le vecteur de nombre d'iteration de la methode de gradient pas fixe(1,1)
m(i)=gradientpasfixe([0;1],0.001,l(i),t,y);%levecteur de nombre d'iteration de la methode de de gradient pas fixe(0,1)
  
end 
figure
hold on 
plot(l,m,'r')
plot(l,z,'b')
xlabel('-log(epsilon)')
ylabel('nombre d iteration')
title('courbe de variation de nombre d iteration de la methode de gradient pas fixe  en f(-log(epsilon))')
end