function animation()
load partie3
figure
plot(t,y,'.')
hold on 

z=inertie([1;0],[0;1],0.001,0.001,0.004,t,y);% appel de la fonction inertie 
a=z(1);                        
b=z(2);
m=a*(1-exp(b*t));               % le calcul du vecteur y chapeau
 m  
h = plot(t,m, 'YDataSource', 'm');
for k = 0.1:0.01:1
m=a*(1-exp(b*t.*k));        
   refreshdata(h, 'caller') 
   drawnow
end
end