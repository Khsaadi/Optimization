function grapheerreur(t,y)  %permet de visualiser la courbe de l'erreur
A = linspace(-10,10,10);
B = linspace(-10,10,10);
[R,U]=meshgrid(A,B); 
for i =1:length(R)
      for j =1:length(U)
             E(i,j) = erreur(R(i),U(j),t,y) ;
end
end
figure
surf(R,U,E);
contour(A,B,E);
 

end