function test22(t,y)             
 [D,Q]=meshgrid(-10:0.1:10,-10:0.1:10);
for i = 1: size(D,1)
    for j= 1 : size(Q,1)  
        E(i,j) =erreur(D(i,j),Q(i,j),t,y) ;
    end
end
figure ;
mesh(D,Q,E);
[c,h]=contour(D,Q,E);% les courbes de niveaux
clabel(c,h) ;
 hold on 
i=1;
R=inertie([1;1],[1;1],0.001,0.001,0.09,t,y) ;% appel de la methode d'inertie pour le pint de depart(1,0)
while (i<size(R,2))
plot([R(1,i),R(1,i+1)],[R(2,i),R(2,i+1)],'-gs','LineWidth',2,'color','r'); %le tracage du trajectoire des iteration 
i=i+1;
end
colormap(cool);
title(' le trajectoir pour le methode de inertie ');
end



