function z=Gradientmultiple2(X,y,lambda) %d�termine la hessienne
 
a=2*transpose(X)*X;
b=2*lambda*eye(7);
z=a+b
end
