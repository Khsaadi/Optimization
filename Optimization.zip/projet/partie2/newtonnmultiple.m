function a1=newtonnmultiple(a0,eps,X,y,lambda)%fonction minimisant la valeur de l'erreur en fonction de a
a1=a0-(Gradientmultiple2(X,y,lambda))^(-1)*(Gradientmultiple(a0,X,y,lambda));
  s=[a0 a1];
  i=0;
while(norm(a1-a0)>eps)
    a0=a1;
    a1=a1-((Gradientmultiple2(X,y,lambda))^(-1))*(Gradientmultiple(a1,X,y,lambda));
    s=[s , a1];
    i=i+1;
end
   i ;
end