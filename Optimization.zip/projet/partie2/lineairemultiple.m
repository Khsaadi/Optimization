function z=lineairemultiple(X,y) %cette fonction permet de calculer 
                                  %les param�tres qui minimisent l'erreur 

l=transpose(X)* X;
h=transpose(X)*y;
z=l^(-1)*h;
end

