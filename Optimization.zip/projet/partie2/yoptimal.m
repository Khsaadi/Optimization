function yoptimal (a0,eps,y,X) 
for i=1: length(y) 
a=newtonnmultiple(a0,eps,X,y,i); %Appel � la m�thode newton multiple
Z(:,i)=y                      % matrice contenant les vecteurs de y
Yoptima(:,i)=X*a ;         % matrice contenant les vecteurs de yoptimale pour chaque valeur de lambda 
end
hold on 
xlabel(' la variation de lambda ');
ylabel(' le vecteur y  ');
plot(1:length(y) ,Z);             
ylabel(' le vecteur y chapeau optimal ');
plot(1:length(y) ,Yoptima);   % affichage de yoptimale en fonction de lambda 

hold off 
title('la variation de y chapeau optimal en fonction de celle de lambda');
end 

