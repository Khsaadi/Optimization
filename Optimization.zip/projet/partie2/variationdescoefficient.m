function variationdescoefficient (X,y,eps,a0) % la variation des valeurs des coe?cients en fonction de ?
lambda=linspace(0.00001,0.1,10);
a1=ones(10);
a2=ones(10);
a3=ones(10);
a4=ones(10);
a5=ones(10);
a6=ones(10);
a7=ones(10);
for i=1:(size(lambda,2))
    a=newtonnmultiple(a0,eps,X,y,lambda(i));
       a
    a1(i)=a(1)
     a2(i)=a(2); 
    a3(i)=a(3);
   a4(i)=a(4);
   a5(i)=a(5);
   a6(i)=a(6);
   a7(i)=a(7);
  
end

figure
hold on 
plot(lambda,a1,'r'); %tra�age dE COURBE
plot(lambda,a2,'g');
plot(lambda,a3,'b');
plot(lambda,a4);
plot(lambda,a5);
plot(lambda,a6);
plot(lambda,a7);
hold off
xlabel('-log(epsilon)')
ylabel('la variation des 7 coefficinet')
title('courbe de variation des 7 coefficients en focntion de la variation de lambda ')


end
    