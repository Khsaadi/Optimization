function z=Gradientmultiple(a,X,y,lambda) % calcule le gradient de l'erreur 
l=transpose(X)*X;
h=transpose(X)*y;
z=2*l*a-2*h+(2.*lambda)*a;    

end