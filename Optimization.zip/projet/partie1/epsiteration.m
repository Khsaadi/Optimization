function epsiteration (x,y)
v=linspace(0.00001,0.1,10);   %le vecteur des epsilon 
l=-log(v);                    % le vecteur de -log(epsilon)
z=ones(10);
m=ones(10);

for i =1 : length(l)
z(i)=gdfx([1;0],0.01,l(i),x,y);%le vecteur de nombre d'iteration de la methode de pasfixe pour le point de depart(1,0)
m(i)=gdfx([0;1],0.0l,(i),x,y);%le vecteur de nombre d'iteration de la methode de pasfixe pour le point de depart(0,1)
  
end 
figure
hold on 

plot(l,m,'r')
plot(l,z)
xlabel('-log(epsilon)')
ylabel('nombre d iteration')
title('courbe de variation de nombre d iteration de la methode de gradien de pasfixe en f(-log(epsilon))')

end
 
 