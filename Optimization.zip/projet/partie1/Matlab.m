function z=Matlab(a,b,x,y)   % calcul fde l'erreur 
w=ones(101,1);
M=[w ,x];   %la matrice M  (101,2)
n=M*[a;b]-y;
z=norm(n)^2;

end
