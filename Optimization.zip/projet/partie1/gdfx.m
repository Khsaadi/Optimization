function i=gdfx(x0,rou,eps,x,y)       % la methode de gradient a pas fixe 
x1=x0-rou*gd(x0(1),x0(2),x,y);          % le calcule de x1
X=[x0 x1];                               % la matrice X conserve les vecteurs calcules 
i=1;
while(norm(x1-x0)>eps)                                   % condition d'arret 
    x0=x1;
    x1=x1-rou*gd(x0(1),x0(2),x,y);          % le calcul du vecteur suivant 
    X=[X x1];
    i=i+1;                                           % i est le nombre d'itaration 
    
end
i
end