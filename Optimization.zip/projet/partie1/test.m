function test(x,y)           
[A , B]=meshgrid(-10:0.1:10,-10:0.1:10);        
for i = 1: size(A,1)
    for j= 1 : size(B,1)   
        E(i,j) = Matlab(A(i,j),B(i,j),x,y) ;
    end
end
figure ;
mesh(A,B,E);
[c,h]=contour(A,B,E); 
hold on % les courbes de niveaux
clabel(c,h) ;
i=1;
X=pasopt([0;1],0.0001,x,y) ;
while i<size(X,2)
plot([X(1,i),X(1,i+1)],[X(2,i),X(2,i+1)],'-gs','LineWidth',2,'color','b'); %le tracage du trajectoire des iteration 
i=i+1;
end
colormap(cool);
title(' ');
hold off
end
