function A=gd1(x)
 w=ones(101,1);
 c=[w   , x];
 A=transpose(c)*c;
end