function i=pascong(x0,eps,x,y)    % la methode de gradient a pas conjugee
 w=ones(101,1);               
 c=[w x];
 k=c';
 A=c'*c;
 b=c'*y;
 r0=A*x0-b;
 d0=r0;                 % d0 est la premiere direction
 rou0=dot(r0,r0)/dot(A*d0,d0);    % la calcul de rou0
 x1=x0-rou0*d0;             %le calcul de x1 
 X=[x0 x1];         % la matrice X conserve les vecteurs calcules 
 i=1;
 while (norm(x1-x0)>eps)            % condition d'arret 
    x0=x1;
    r=A*x1-b;             % calcul de nouveau rou 
    beta=(norm(r)^2)/(norm(r0)^2);          % calcul de betta 
    d=r+beta*d0;                       % la nouvelle direction 
    rou=dot(r,r)/dot(A*d,d);
    x1=x1-rou*d;
    X=[X x1];            
    i=i+1;             % nombre d'iteration 
    r0=r;
    d0=d   ; 
 end 
 i
end