function z=Gradient
load partie1
syms  a b 
z=gradient(Matlab(a,b,x,y));
end