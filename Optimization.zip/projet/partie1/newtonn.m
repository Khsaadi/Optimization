function X=newtonn(x0,eps,x,y)         
  x1=x0-(gd1(x)^(-1))*gd(x0(1),x0(2),x,y);    % le calcul de x1 
  X=[x0 x1];          % X est une matrice qui contient les vecteurs calcul�s 
  i=0;                    % initialisation de i qui va calculer le nombre d'it�ration 
while(norm(x1-x0)>eps)  % condition d'arret 
    x0=x1;
    x1=x1-(gd1(x)^(-1))*gd(x1(1),x1(2),x,y);  % calcul du  vecteur suivant 
    X=[X x1];         %on insere le nouveau vecteur dans X 
    i=i+1;                  
end
   i        % affichage du nombre d'iteration 
end