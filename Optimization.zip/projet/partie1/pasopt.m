function i= pasopt(x0,eps,x,y)
 w=ones(101,1);           % vecteur colone remplie de 1 
 c=[w x];                   % la matrice(101,2)
 A=c'*c;                
 b=c'*y;
 r0=A*x0-b;
 rou0=dot(r0,r0)/dot(A*r0,r0);           % le calcul de rou0
 x1=x0-rou0*gd(x0(1),x(2),x,y);         %le calcul de x1 
 X=[x0 x1];                         % la matrice X conserve les vecteurs calcules 
 i=1;
while (norm(x1-x0)>eps)      % condition d'arret 
    x0=x1;
    r=A*x1-b;
    rou=dot(r,r)/dot(A*r,r);
    x1=x1-rou*gd(x1(1),x1(2),x,y);
    X=[X x1];
    i=i+1;                  % i est le nombre d'itaration 
    
end
i
end