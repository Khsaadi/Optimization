function quiverr(x,y)         
[A , B]=meshgrid(-10:0.1:10,-10:0.1:10);        
for i = 1: size(A,1)
    for j= 1 : size(B,1)   
        E(i,j) = Matlab(A(i,j),B(i,j),x,y) ;
    end
end
figure  
mesh(A,B,E);
[c,h]=contour(A,B,E); %courbe de niveaux 
clabel(c,h);
[p1 ,p2]=gradient(E) %le gradient de E 
quiver(A,B,p1,p2);  %m�thode quiver
end